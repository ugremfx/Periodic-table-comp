% Assignment 6

clc
clear all

%%
Z = 10; % For Neon
No_el = 10; % Total number of electrons

lval = 0:1; % Azimuthal quantum number range (angular momentum)
Nocc = [2; 2; 6]; %Column vector with occupation numbers [1s 2s 2p 3s 3p 4s 3d 4p 5s ...] in ocupation order
nvalj =  [1; 2; 2]; % Vector that stores the nval corresponding to each subshell occupied
lvalj = [0; 0; 1]; % Vector that stores the lval corresponding to each subshell occupied


%%
% Z = 10; % For Neon ion
% No_el = 9; % Total number of electrons
% 
% lval = 0:1; % Azimuthal quantum number range (angular momentum)
% Nocc = [2; 2; 5]; %Column vector with occupation numbers [1s 2s 2p 3s 3p 4s 3d 4p 5s ...] in ocupation order
% nvalj =  [1; 2; 2]; % Vector that stores the nval corresponding to each subshell occupied
% lvalj = [0; 0; 1]; % Vector that stores the lval corresponding to each subshell occupied


% % %%
% Z = 2; % For Helium
% No_el = 2; % Total number of electrons
% 
% lval = 0; % Vector with Azimuthal quantum numbers (angular momentum) met in the atom.
% Nocc = [2]; %Column vector with occupation numbers [1s 2s 2p 3s 3p 4s 3d 4p 5s] in ocupation order
% nvalj =  [1]; % Vector that stores the nval corresponding to each subshell occupied 
% lvalj = [0]; % Vector that stores the lval corresponding to each subshell occupied



%% Construct the computational domain sequence

%  r = [linspace(1e-12,1e-9,500) ...
%      linspace(1.01e-9,1e-6,100) ...
%      linspace(1.01e-6,1e-3,1500) ...
%      linspace(1.01e-3,1,2500)...
%      linspace(1.01,200,1500)]; % Bohr radiuses

% r = logspace(-5,3,20000); % Bohr radiuses
% r =r/(1e3)*5;

%r = linspace(1e-10,20,20000); % Bohr radiuses for Neon

r = linspace(1e-8,20,5000); % Bohr radiuses for He

kord = 4; % The order of splines. For cubic splines kord = 4



%% Knot points
tknot = repmat(r(1),1,kord);
kk = kord;
kh = 20; % Counter for selecting knot points, after the beginning of radius
while kh <= length(r)
    kk = kk+1;
    tknot(kk) = r(kh);
    kh = kh + 100; % Adjust here the step for taking knot points
end
tknot = [tknot repmat(r(end),1,kord)];

% tknot values must be included in r vector!
if ~issorted(tknot)
    fprintf('Knot points are not sorted!\n')
return
end


%% Generate the splines and their derivatives
[Bavx,dBavx,dB2avx] = bsplgen(r,tknot,kord); % Generate the B-splines on the given grid and knot points
r = r'; % Transpose in order to work with column vectors
tknot = tknot';

N = length(tknot); % Number of knot points


%% Initializations for the potentials

Vdir = zeros(length(r),1); % Potential obtained from Poisson eq. Eq. no 12
Vexch = zeros(length(r),1); % Pauli potential eq. 14
Vee = zeros(length(r),1);

%%

jk = 0; % Iterations counter
while jk < 20
jk = jk + 1;



Pnl = zeros(length(r),N-kord,length(lval)); % Initialize P_nl
% Construct matrices H and B. Solve P_nl for all orbitals (different values
% of l)
for kk = 1:length(lval)
    % Initializations
    H = zeros(N-kord,N-kord); % Initialization with a aquare zero matrix of dimensions N-kord
    B = H;
    
    for ii = 1:size(H,1)
        for jj = 1:size(H,2)
            % Point charge Coulomb potential
            int_interv = (r >= tknot(max(ii,jj))) & (r <= tknot(min(ii,jj)+kord)); % Logical array corresponding to the integration interval in r, where splines are non-zero
            Hfunc_to_int = Bavx(int_interv,jj).*(-1/2*dB2avx(int_interv,ii) + 1/2.*lval(kk).*(lval(kk)+1).*1./((r(int_interv)).^2).*Bavx(int_interv,ii) - Z./r(int_interv).*Bavx(int_interv,ii) + Vee(int_interv,jk).*Bavx(int_interv,ii));
            % Integrate the integrand
%             H(ii,jj) = Gauss_int(r(int_interv), Hfunc_to_int,64);
%             B(ii,jj) = Gauss_int(r(int_interv),Bavx(int_interv,jj).*Bavx(int_interv,ii),64);
            if length(Hfunc_to_int) > 1 % Integrate with trapz
            H(ii,jj) = trapz(r(int_interv), Hfunc_to_int);
            B(ii,jj) = trapz(r(int_interv),Bavx(int_interv,jj).*Bavx(int_interv,ii));
            else
            H(ii,jj) = 0;
            B(ii,jj) = 0;
            end
            
            
        end
    end
    
    % Modify H matrix with boundary conditions
    % Remove the first and the last B splines
      H = H(2:(N-kord-1),2:(N-kord-1));
      B = B(2:(N-kord-1),2:(N-kord-1));
    
    
    %% Solve the Generalized Eigenvalue problem
    [c,E] = eig(H,B); % Each column in matrix c is an eigenvector. Each row corresponds to a B-spline coeffcient (see eq. 4)
    Ener(:,kk,jk) = diag(E); % Vectors obtained by extracting the diagonal of matrix E , kk corresponds to the lval, jk to the outer while loop
    
    
    %% Sort results to obtain the ground state
    [Ener_ord, Ind_ener] = sort(Ener,1,'ascend');
    c_ord = c(:,Ind_ener);
    
    
    %% Calculate P_nl
    for jj = 1:(N-kord-2) % Diferent fundamental n value numbers
        for ii = 1:(N-kord-2)
            Pnl(:,jj,kk) = Pnl(:,jj,kk) + c_ord(ii,jj)*Bavx(:,ii);
        end
    end
    
end % end for loop to lval


%% Calculate rho with equation (9)
rho(:,jk) = zeros(length(r),1); % Electronic radial charge density
for kl = 1:length(Nocc) % Nocc is a vector with the occupied orbitals and how many electrons are in each orbital
    rho(:,jk) = rho(:,jk) + (1/(4*pi)).*Nocc(kl).*(Pnl(:,nvalj(kl),lvalj(kl)+1)./r).^2;
end

% Normalize rho eq. (10)
Int_norm = 4.*pi.*trapz(r,rho(:,jk).*(r.^2))./No_el;
%Int_norm = 4.*pi.*Gauss_int(r,rho(:,jk).*(r.^2),64)./No_el;
rho(:,jk) = rho(:,jk)/Int_norm;


%% Poisson equation
toler = 1e-14*ones(length(r),1); % A vector of tolerances
% Matrix and free term definition
% Boundary conditions
%alfa = 0; % Boundary condition at the center of the sphere; phi(0) == 0 
beta = No_el; % [Volt meter] Boundary condition at the end of the domain, much larger than the radius R;  phi(r>R) == Q/(4*pi*eps_0)

B = -tknot(kord:(end-kord+1)).*interp1(r,rho(:,jk),tknot(kord:(end-kord+1))); % Right hand side of system of equations
B = [B; beta]; % Augment with the boundary conditions. alfa = phi(0)

% Matrix 
no_Bspl = length(tknot) - kord; % Total number of B-splines
A = zeros(no_Bspl-1,no_Bspl-1); % Pre-allocate the full matrix to be solved

% Assign the matrix block corresponding to the physical points
for ii  = 1:(no_Bspl-2)
    A(ii,ii)   = dB2avx(abs(r - tknot(ii+kord-1)) < toler , ii);
    A(ii,ii+1) = dB2avx(abs(r - tknot(ii+kord-1)) < toler, ii+1);
    A(ii,ii+2) = dB2avx(abs(r - tknot(ii+kord-1)) < toler, ii+2);
end
A(end,end-2) = Bavx(abs(r - tknot(end-kord+1)) < toler,end-2); % The eq. corresponding to the right boundary condition, in the last physical point
A(end,end-1) = Bavx(abs(r - tknot(end-kord+1)) < toler,end-1); 
A(end,end  ) = Bavx(abs(r - tknot(end-kord+1)) < toler,end);


%% Solve the system
cn = A\B; % The unknowns are all the coefficients c_n for the B-splines

phi = 0; % Initialize
for ii = 1:length(cn)
    phi = phi + cn(ii)*Bavx(:,ii); % Assemble the solution based on B-splines and their coefficients
end


%% Calculate Vee

Vdir(:,jk+1) = phi./r; % Divide with r to obtain the potential
Vexch(:,jk+1) =  -3.*(3.*rho(:,jk)./(8*pi)).^(1/3);

eta = 0.7; % Higher eta means higher damping
Vee(:,jk+1) = (Vdir(:,jk+1) + Vexch(:,jk+1))*(1-eta) + eta*(Vdir(:,jk) + Vexch(:,jk));


%% Plot convergence
figure(1)
hold on
%for ii = 1:size(Ener_ord,3)
plot(jk,Ener_ord(1,1,jk),'o')
%end
legend('Orbital energies for 1s')
xlabel('Iteration')
ylabel('Energy')

figure(2)
hold on
%for ii = 1:size(Ener_ord,3)
plot(jk,Ener_ord(2,1,jk),'o')
%end
legend('Orbital energies for 2s')
xlabel('Iteration')
ylabel('Energy')

figure(3)
hold on
plot(r,Vee(:,jk+1))
legend('Vee')
ylim([-100,100])

figure(4)
hold on
plot(r,Vdir(:,jk+1))
legend('Vdir')
ylim([-100,100])

figure(5)
hold on
plot(r,Vexch(:,jk+1))
legend('Vexch')
ylim([-100,100])

figure(6)
hold on
plot(r,rho(:,jk))
legend('rho')
ylim([-100,100])


%% Total energy calculation
Orb_ener = Ener_ord(:,:,end); % Energies from the last iteration;
for kl = 1:length(Nocc)
Half_neg_exp_val_pot(kl) = -1/2 * trapz(r,Pnl(:,nvalj(kl),lvalj(kl)+1).*Vee(:,end).*Pnl(:,nvalj(kl),lvalj(kl)+1));
Total_ener_per_orb(kl) = (Half_neg_exp_val_pot(kl) + Orb_ener(nvalj(kl),lvalj(kl)+1))*Nocc(kl);
end
Total_ener_atom = sum(Total_ener_per_orb);

end % while loop

fprintf('\nAt the end of iterations:\n')
fprintf('Orbital energy for orbital 1s is: %12.3f \n',Orb_ener(1,1))
fprintf('Negative half of expectaion value is: %12.3f \n',Half_neg_exp_val_pot(end))
fprintf('Total energy per atom is: %12.3f \n\n',Total_ener_atom)


%%

figure
plot(r, 4*pi*r.^2.*rho(:,end))
xlim([0 4]);
xlabel('Bohr radii')
ylabel('Electron probability density 4pi*r^2*rho')


%% Plots
Noptr = 4; % Number of points to remove at the origin
fqn_n = 1; % Fundamental quantum number used for plots below
fqn_l = 1; % Quantum Spin number
 
figure
plot(r(Noptr:end),Pnl(Noptr:end,fqn_n,fqn_l)./r(Noptr:end),'Linewidth',1.2)
hold on
plot(r(Noptr:end),Pnl(Noptr:end,fqn_n+1,fqn_l)./r(Noptr:end),'-','Linewidth',1.2)
hold off
xlabel('r [Bohr radiuses]')
ylabel('Radial wavefunction $R_{nl} = P_{nl}/r$','interpreter','latex')
legend(sprintf('R_{%d%d}',fqn_n,lval(fqn_l)),sprintf('R_{%d%d}',fqn_n+1,lval(fqn_l)))
grid on
%xlim([0,10])
ylim([-1,5])



